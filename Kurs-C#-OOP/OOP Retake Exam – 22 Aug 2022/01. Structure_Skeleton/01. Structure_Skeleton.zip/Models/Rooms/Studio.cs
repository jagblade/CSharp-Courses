﻿namespace BookingApp.Models.Rooms
{
    internal class Studio : Room
    {
        private const int studioBedCappacity = 4;
        public Studio() : base(studioBedCappacity)
        {

        }

    }
}
