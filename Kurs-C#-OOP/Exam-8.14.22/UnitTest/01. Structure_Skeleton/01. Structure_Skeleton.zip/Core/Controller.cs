﻿namespace PlanetWars.Core

{
    using PlanetWars.Core.Contracts;

    internal class Controller : IController
    {
        public string AddUnit(string unitTypeName, string planetName)
        {
            throw new System.NotImplementedException();
        }

        public string AddWeapon(string planetName, string weaponTypeName, int destructionLevel)
        {
            throw new System.NotImplementedException();
        }

        public string CreatePlanet(string name, double budget)
        {
            throw new System.NotImplementedException();
        }

        public string ForcesReport()
        {
            throw new System.NotImplementedException();
        }

        public string SpaceCombat(string planetOne, string planetTwo)
        {
            throw new System.NotImplementedException();
        }

        public string SpecializeForces(string planetName)
        {
            throw new System.NotImplementedException();
        }
    }
}
