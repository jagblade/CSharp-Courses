﻿
namespace P03.Raiding
{
    using System;
    using P03.Raiding.Core;
    internal class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
