﻿namespace P03.Raiding
{
    public enum HeroType
    {
        Druid = 1,
        Paladin = 2,
        Rogue = 3,
        Warrior = 4
    }
}