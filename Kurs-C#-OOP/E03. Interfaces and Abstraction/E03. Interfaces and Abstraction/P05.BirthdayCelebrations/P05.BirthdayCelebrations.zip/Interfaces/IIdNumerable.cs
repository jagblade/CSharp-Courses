﻿
namespace P05.BirthdayCelebrations
{
    public interface IIdNumerable
    {
        public string Id { get; }
    }
}
