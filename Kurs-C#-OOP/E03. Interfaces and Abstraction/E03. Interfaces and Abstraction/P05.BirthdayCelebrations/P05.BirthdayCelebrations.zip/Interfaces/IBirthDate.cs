﻿namespace P05.BirthdayCelebrations
{ 
    using System;
    public interface IBirthDate
    {
        DateTime BirthDate { get; }
    }
}
