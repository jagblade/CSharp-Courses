﻿namespace PersonInfo.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
